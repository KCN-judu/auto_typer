#pragma once

#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <Wire.h>

#include "app_config.h"
#include "app_types.h"

namespace test_app {

class DisplayHal {
 public:
  explicit DisplayHal(const OledConfig& config)
      : config_(config),
        display_(config.width, config.height, &Wire, -1, config.preclkHz, config.postclkHz),
        ready_(false) {}

  bool init(uint8_t address) {
    ready_ = display_.begin(address, false);
    if (!ready_) {
      return false;
    }

    display_.clearDisplay();
    display_.setTextSize(1);
    display_.setTextColor(SH110X_WHITE);
    show(frameBootOk());
    return true;
  }

  void show(const DisplayFrame& frame) {
    if (!ready_) {
      return;
    }

    display_.clearDisplay();
    drawLine(0, frame.line0);
    drawLine(8, frame.line1);
    drawLine(16, frame.line2);
    drawLine(24, frame.line3);
    display_.display();
  }

  bool ready() const {
    return ready_;
  }

  void markUnavailable() {
    ready_ = false;
  }

 private:
  void drawLine(int16_t y, const char* text) {
    display_.setCursor(0, y);
    if (text != nullptr) {
      display_.print(text);
    }
  }

  OledConfig config_;
  Adafruit_SH1106G display_;
  bool ready_;
};

}  // namespace test_app
